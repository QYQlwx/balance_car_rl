#include "policy_inference.h"
#include <math.h>

/* 动态校准的 IMU pitch 偏置 (开机时测量) */
static float g_imu_pitch_bias = 0.0f;
static int   g_calib_counter  = 0;
static float g_calib_sum      = 0.0f;
#define CALIB_SAMPLES 500    /* 100Hz x 5秒 = 500 个样本 */

static void update_imu_calibration(float pitch_deg)
{
    if (g_calib_counter < CALIB_SAMPLES)
    {
        g_calib_sum += pitch_deg * DEG_TO_RAD;
        g_calib_counter++;
        if (g_calib_counter == CALIB_SAMPLES)
        {
            /* 校准完成, 取平均作为偏置 */
            g_imu_pitch_bias = g_calib_sum / (float)CALIB_SAMPLES;
        }
    }
}

static float elu(float x)
{
    if (x >= 0.0f) return x;
    return expf(x) - 1.0f;
}

static float clampf(float x, float lo, float hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static void fc_layer(const float *input,
                     const float *weight,
                     const float *bias,
                     float       *output,
                     int          in_dim,
                     int          out_dim,
                     int          use_elu)
{
    int i, j;
    for (i = 0; i < out_dim; i++) {
        float acc = (bias != 0) ? bias[i] : 0.0f;
        const float *row = weight + i * in_dim;
        for (j = 0; j < in_dim; j++) {
            acc += row[j] * input[j];
        }
        output[i] = use_elu ? elu(acc) : acc;
    }
}

void policy_forward(const policy_obs_t *obs, policy_action_t *action)
{
    float obs_array[POLICY_INPUT_DIM];
    float hidden1[POLICY_HIDDEN1_DIM];
    float hidden2[POLICY_HIDDEN2_DIM];
    float out[POLICY_OUTPUT_DIM];

    obs_array[0] = obs->pitch;
    obs_array[1] = obs->pitch_vel;
    obs_array[2] = obs->yaw_vel;
    obs_array[3] = obs->left_wheel_vel;
    obs_array[4] = obs->right_wheel_vel;
    obs_array[5] = obs->last_action_left;
    obs_array[6] = obs->last_action_right;

    fc_layer(obs_array,
             (const float *)&fc1_weight[0][0], fc1_bias,
             hidden1, POLICY_INPUT_DIM, POLICY_HIDDEN1_DIM, 1);

    fc_layer(hidden1,
             (const float *)&fc2_weight[0][0], fc2_bias,
             hidden2, POLICY_HIDDEN1_DIM, POLICY_HIDDEN2_DIM, 1);

    fc_layer(hidden2,
             (const float *)&fc3_weight[0][0], fc3_bias,
             out, POLICY_HIDDEN2_DIM, POLICY_OUTPUT_DIM, 0);

    action->left  = clampf(out[0], -1.0f, 1.0f);
    action->right = clampf(out[1], -1.0f, 1.0f);
}

void policy_compute_observation(
    float                  pitch_deg,
    short                  pitch_vel_lsb,
    short                  yaw_vel_lsb,
    int                    encoder_left,
    int                    encoder_right,
    const policy_action_t *last_action,
    policy_obs_t          *obs)
{
    float wheel_l, wheel_r;

    /* 实测 PID 平衡时 angle = -6° (即 pitch_deg = -6.0)
     * 该值就是车的"真实机械平衡点"
     * 我们让 obs.pitch 在此姿态下为 0, 与仿真训练对齐 */
    obs->pitch     = (pitch_deg + 9.0f) * DEG_TO_RAD;
    /* 解释: pitch_deg = -6 时, obs.pitch = (-6+6) × 0.01745 = 0 */
    obs->pitch_vel = (float)pitch_vel_lsb * GYRO_LSB_TO_RADPS;
    obs->yaw_vel   = (float)yaw_vel_lsb   * GYRO_LSB_TO_RADPS;

    wheel_l = ENC_TO_RADPS(encoder_left)  / POLICY_ACTION_SCALE;
    wheel_r = ENC_TO_RADPS(encoder_right) / POLICY_ACTION_SCALE;
    obs->left_wheel_vel  = clampf(wheel_l, -2.0f, 2.0f);
    obs->right_wheel_vel = clampf(wheel_r, -2.0f, 2.0f);

    obs->last_action_left  = last_action->left;
    obs->last_action_right = last_action->right;
}

void policy_action_to_pwm(const policy_action_t *action,
                          int *pwm_left, int *pwm_right)
{

    const float effective_gain = -1.2f;
    int pwm_l, pwm_r;
    float raw_l, raw_r;

    raw_l = action->left  * effective_gain * (float)POLICY_PWM_MAX;
    raw_r = action->right * effective_gain * (float)POLICY_PWM_MAX;

    pwm_l = (int)clampf(raw_l, -(float)POLICY_PWM_MAX, (float)POLICY_PWM_MAX);
    pwm_r = (int)clampf(raw_r, -(float)POLICY_PWM_MAX, (float)POLICY_PWM_MAX);

    /* 死区补偿 */
    if (pwm_l >  0 && pwm_l <  350) pwm_l =  350;
    if (pwm_l <  0 && pwm_l > -350) pwm_l = -350;
    if (pwm_r >  0 && pwm_r <  350) pwm_r =  350;
    if (pwm_r <  0 && pwm_r > -350) pwm_r = -350;

    *pwm_left  = pwm_l;
    *pwm_right = pwm_r;
}


int policy_safety_check(float pitch_rad)
{
    float abs_pitch = pitch_rad < 0.0f ? -pitch_rad : pitch_rad;
    return (abs_pitch > POLICY_PITCH_LIMIT) ? 1 : 0;
}

void policy_reset_calibration(void)
{
    g_imu_pitch_bias = 0.0f;
    g_calib_counter = 0;
    g_calib_sum = 0.0f;
}
