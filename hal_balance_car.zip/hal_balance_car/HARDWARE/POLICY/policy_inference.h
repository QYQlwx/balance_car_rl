#ifndef POLICY_INFERENCE_H
#define POLICY_INFERENCE_H

/* policy_weights.h 已定义 POLICY_INPUT/HIDDEN1/HIDDEN2/OUTPUT_DIM 及权重数组 */
#include "policy_weights.h"

/* 物理/控制常量 */
#define POLICY_ACTION_SCALE  25.0f
#define POLICY_PWM_MAX       7200
#define POLICY_PITCH_LIMIT   1.047f   /* 60度 = 60 * π/180 */

#define DEG_TO_RAD           0.01745329f
/* MPU6050 ±2000dps: 1LSB = 2000/32768 °/s × π/180 = 0.001065264 rad/s */
#define GYRO_LSB_TO_RADPS    0.0010653f

#define ENCODER_PPR          1320.0f
#define CONTROL_FREQ         100.0f

#define ENC_TO_RADPS(pulses) \
    (((float)(pulses) / ENCODER_PPR) * 6.28318530f * CONTROL_FREQ)

typedef struct {
    float pitch;
    float pitch_vel;
    float yaw_vel;
    float left_wheel_vel;
    float right_wheel_vel;
    float last_action_left;
    float last_action_right;
} policy_obs_t;

typedef struct {
    float left;
    float right;
} policy_action_t;

void policy_forward(const policy_obs_t *obs, policy_action_t *action);

void policy_compute_observation(
    float                  pitch_deg,
    short                  pitch_vel_lsb,
    short                  yaw_vel_lsb,
    int                    encoder_left, 
    int                    encoder_right,
    const policy_action_t *last_action,
    policy_obs_t          *obs);

void policy_action_to_pwm(const policy_action_t *action,
                          int *pwm_left, int *pwm_right);

int  policy_safety_check(float pitch_rad);

/* 重置 RL 上一拍动作（供模式切换调用，定义在 control.c）*/
void policy_reset_last_action(void);

void policy_reset_calibration(void);

#endif
